<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <v-app>
    <v-layout>
      <RouterView>
        
      </RouterView>
    </v-layout>
  </v-app>
</template>

