<script lang="ts" setup>

</script>
<template>

 <h1>Apply </h1>
</template>