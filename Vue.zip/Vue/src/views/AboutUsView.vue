<script lang="ts" setup>

</script>
<template>
<h1>About us</h1>
</template>