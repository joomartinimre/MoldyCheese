<script lang="ts" setup>

</script>
<template>

<h1>School View</h1>
</template>