<script lang="ts" setup>

</script>
<template>

<h1>Restaurant View</h1>
</template>