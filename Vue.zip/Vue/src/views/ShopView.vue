<script lang="ts" setup>

</script>
<template>

<h1>Shop View</h1>
</template>