import axios from 'axios'

const axiosClient = axios.create({})

export default axiosClient
