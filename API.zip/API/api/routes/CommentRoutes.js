const express = require("express");
const CommentController = require("../controllers/CommentController");
const router = express.Router();

// Új komment létrehozása (bejelentkezett felhasználóknak)
router.post("/comment", CommentController.addComment);

// Kommentek lekérése egy helyhez
router.get("/comments/:place_ID", CommentController.getCommentsByPlace);

// Komment törlése (csak saját vagy admin jogosultság esetén)
router.delete("/comment/:id", CommentController.deleteComment);

module.exports = router;
